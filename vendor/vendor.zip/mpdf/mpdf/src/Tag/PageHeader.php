<?php

namespace Mpdf\Tag;

class PageHeader extends PageFooter
{

}
